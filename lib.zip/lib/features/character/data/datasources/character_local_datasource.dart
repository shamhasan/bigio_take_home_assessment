import 'package:bigio_test_app/features/character/data/models/character_models.dart';
import 'package:sqflite/sqflite.dart';
import 'package:bigio_test_app/features/character/domain/entities/character_entity.dart';

abstract class CharacterLocalDatasource {
  Future<List<CharacterEntity>> getFavorites();
  Future<void> addFavorite(CharacterModels char);
  Future<void> removeFavorite(int id);
  Future<bool> isFavorite(int id);
}

class CharacterLocalDatasourceImpl extends CharacterLocalDatasource {
  final Database database;

  CharacterLocalDatasourceImpl({required this.database});

  @override
  Future<void> addFavorite(CharacterModels char) async {
    try {
      await database.insert(
        'favorites',
        char.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<List<CharacterEntity>> getFavorites() async {
    final List<Map<String, dynamic>> maps = await database.query('favorites');
    return maps.map((e) => CharacterModels.fromMap(e)).toList();
  }

  @override
  Future<bool> isFavorite(int id) async {
    final result = await database.query(
      'favorites',
      where: 'id = ?',
      whereArgs: [id],
    );

    return result.isNotEmpty;
  }

  @override
  Future<void> removeFavorite(int id) async {
    try {
      await database.delete('favorites', where: 'id = ?', whereArgs: [id]);
    } catch (e) {
      rethrow;
    }
  }
}
